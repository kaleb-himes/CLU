run whichever .sh you want to generate a plain text file containing the number
of lines specified in the .sh filename. Test encrypting and decrypting on these
ascii based files.

