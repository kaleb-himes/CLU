rm somejunk*.txt
