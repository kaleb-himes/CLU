These are the NIST test vectors provided for functionality verification.

Simply run the two shell scripts (.sh files) in order to initiate the testing processes.
This may take several minutes.

Make sure that you have run 'make' so the program will run correctly.
